package com.fpl.jason_fpl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JasonFplApplication {

	public static void main(String[] args) {
		SpringApplication.run(JasonFplApplication.class, args);
	}

}
