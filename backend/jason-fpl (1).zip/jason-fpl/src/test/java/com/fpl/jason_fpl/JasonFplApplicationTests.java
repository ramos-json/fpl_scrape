package com.fpl.jason_fpl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JasonFplApplicationTests {

	@Test
	void contextLoads() {
	}

}
